import java.util.Scanner;

public class app {

    // static int n = 0;
    // static String s = " ggghgffg";
    // static String sn = ("add two variable = " + n + s);

    // ===============Input method For java =================================//

    public static void main(String[] args) {

        
        //Scanner scan = new Scanner(System.in);

        // ================================charector===================================//
        //Scanner scan = new Scanner(System.in);
        // System.out.println("Enter the Charector Value ");
        // char ch = scan.next().charAt(0);
        // System.out.println("Your Enter Charector Value is = " +ch);
       // =================================== string // ==================================//
     
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the String  Value  ");
        String st = scan.next();
        System.out.println("Your Enter String  Value is  =  " + st);
        // ============================ integer======================================//
        //Scanner scan = new Scanner(System.in);
        // System.out.println("Enter the Integer Value ");
        // int inData = scan.nextInt();
        // System.out.println("Your Enter Value is = " + StData);
        // =========================================================================//


        //===================================================//
        // int n = 10;
        // String s = " ";
        // String add = n + s;

        // System.out.println("enter the value ");
        // String sn = ("add two variable = " + n + s);
        // System.out.println(sn);
        //====================================================//

        // System.out.println(n);

        // System.out.println(s);

    }

}
